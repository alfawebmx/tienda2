export class Usuario {
  id       : string;
  email    : string;
  password : string;
}