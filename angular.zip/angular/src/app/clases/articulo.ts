export class articulo {
  id          : string;
  nombre      : string;
  descripcion : string;
  imagen      : string;
  precio      : string;
  disponible  : string;
}